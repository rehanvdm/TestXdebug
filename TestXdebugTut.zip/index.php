<?php

phpinfo();
die;